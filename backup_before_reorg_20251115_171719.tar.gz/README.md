# Zerodha Kite Trading Bot

An automated stock trading bot for Zerodha Kite with logic-based reasoning strategies including momentum and RSI-based trading.

## Features

- 🔌 **Zerodha Kite API Integration**: Full integration with Kite Connect API
- 📊 **Multiple Trading Strategies**:
  - Momentum Strategy: Trade based on price momentum
  - RSI Strategy: Trade based on overbought/oversold conditions
- 🎯 **Logic-Based Reasoning**: Make trading decisions based on technical indicators
- 💰 **Risk Management**: Position sizing based on available capital
- 📝 **Comprehensive Logging**: Detailed logs for monitoring and debugging
- ⚙️ **Configurable**: Easy configuration via environment variables

## Project Structure

```
stocks/
├── src/
│   ├── kite_trader/
│   │   ├── __init__.py
│   │   └── trader.py          # Kite API wrapper
│   ├── strategies/
│   │   ├── __init__.py
│   │   ├── base_strategy.py   # Base strategy class
│   │   ├── momentum_strategy.py
│   │   ├── rsi_strategy.py
│   │   └── strategy_manager.py
│   └── utils/
│       ├── __init__.py
│       ├── config.py           # Configuration management
│       └── logger.py           # Logging setup
├── config/
│   └── .env.example           # Configuration template
├── logs/                      # Log files
├── tests/                     # Unit tests
├── main.py                    # Main entry point
├── requirements.txt
└── README.md
```

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure API Credentials

1. Get your API credentials from [Zerodha Kite Connect](https://developers.kite.trade/)
2. Copy the example config file:
   ```bash
   cp config/.env.example .env
   ```
3. Edit `.env` and add your credentials:
   ```env
   KITE_API_KEY=your_api_key_here
   KITE_API_SECRET=your_api_secret_here
   ```

### 3. Generate Access Token

The first time you run the bot, you'll need to generate an access token:

```python
from src.kite_trader.trader import KiteTrader

trader = KiteTrader()
print(trader.get_login_url())
# Visit the URL, login, and copy the request_token from the redirect URL
access_token = trader.set_access_token_from_request("request_token_here")
print(f"Access Token: {access_token}")
# Add this to your .env file as KITE_ACCESS_TOKEN
```

## Usage

### Basic Usage

Edit `main.py` to configure your trading strategies:

```python
from src.kite_trader.trader import KiteTrader
from src.strategies.strategy_manager import StrategyManager

# Initialize trader
trader = KiteTrader()

# Create strategy manager
strategy_manager = StrategyManager(trader)

# Add momentum strategy
strategy_manager.add_strategy(
    'momentum',
    symbols=['RELIANCE', 'TCS', 'INFY'],
    momentum_threshold=0.02,  # 2% momentum
    lookback_days=5
)

# Add RSI strategy
strategy_manager.add_strategy(
    'rsi',
    symbols=['SBIN', 'HDFCBANK'],
    rsi_period=14,
    oversold_threshold=30,
    overbought_threshold=70
)

# Run the strategies
strategy_manager.run(interval_seconds=60)  # Check every 60 seconds
```

### Run the Bot

```bash
python main.py
```

## Trading Strategies

### 1. Momentum Strategy

Trades based on price momentum over a lookback period.

**Logic:**
- **BUY**: When momentum > threshold and no position
- **SELL**: When momentum < -threshold and have position

**Parameters:**
- `momentum_threshold`: Minimum momentum to trigger trade (default: 0.02 = 2%)
- `lookback_days`: Days to look back for momentum calculation (default: 5)
- `max_position_pct`: Max position size as % of capital (default: 0.1 = 10%)

### 2. RSI Strategy

Trades based on Relative Strength Index (RSI) indicator.

**Logic:**
- **BUY**: When RSI < oversold threshold (default: 30)
- **SELL**: When RSI > overbought threshold (default: 70)

**Parameters:**
- `rsi_period`: Period for RSI calculation (default: 14)
- `oversold_threshold`: RSI level to trigger buy (default: 30)
- `overbought_threshold`: RSI level to trigger sell (default: 70)
- `max_position_pct`: Max position size as % of capital (default: 0.1)

## Creating Custom Strategies

Extend the `BaseStrategy` class to create your own strategies:

```python
from src.strategies.base_strategy import BaseStrategy

class MyCustomStrategy(BaseStrategy):
    def analyze(self, symbol: str, market_data: dict) -> Optional[str]:
        # Implement your logic here
        # Return 'BUY', 'SELL', or None
        pass
    
    def calculate_position_size(self, symbol: str, signal: str) -> int:
        # Implement position sizing logic
        return quantity
```

## Configuration

All configuration is managed via environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `KITE_API_KEY` | Your Kite API key | Required |
| `KITE_API_SECRET` | Your Kite API secret | Required |
| `KITE_ACCESS_TOKEN` | Your access token | Optional |
| `MAX_POSITION_SIZE_PCT` | Max position size (%) | 0.1 |
| `RSI_PERIOD` | RSI calculation period | 14 |
| `RSI_OVERSOLD` | RSI oversold threshold | 30 |
| `RSI_OVERBOUGHT` | RSI overbought threshold | 70 |
| `MOMENTUM_THRESHOLD` | Momentum trigger threshold | 0.02 |
| `MOMENTUM_LOOKBACK_DAYS` | Momentum lookback period | 5 |
| `LOG_LEVEL` | Logging level | INFO |

## Risk Management

⚠️ **Important Safety Features:**

1. **Position Sizing**: Automatically calculates position size based on available capital
2. **Maximum Position Limit**: Default 10% of capital per position
3. **Paper Trading**: Enable `ENABLE_PAPER_TRADING=true` for testing
4. **Stop Loss**: Implement in your custom strategies
5. **Logging**: All trades and decisions are logged

## Logging

Logs are stored in the `logs/` directory with daily rotation:
- Console output: INFO level
- File output: DEBUG level with full details
- File format: `trading_YYYYMMDD.log`

## Testing

⚠️ **Before live trading:**

1. Test with paper trading enabled
2. Start with small position sizes
3. Monitor logs carefully
4. Verify strategy logic with historical data

## API Limits

Zerodha Kite has rate limits:
- 3 requests per second
- Keep iteration intervals reasonable (60+ seconds recommended)

## Disclaimer

⚠️ **Trading involves significant risk. This bot is for educational purposes.**

- Always test thoroughly before live trading
- Start with small amounts
- Monitor your positions regularly
- Understand the risks involved
- Past performance doesn't guarantee future results

## Support

For issues with:
- **Kite API**: Check [Kite Connect Documentation](https://kite.trade/docs/connect/v3/)
- **Bot Issues**: Review logs in `logs/` directory
- **Strategy Questions**: Understand technical indicators before implementing

## License

MIT License - Use at your own risk

## Contributing

Feel free to:
- Add new strategies
- Improve risk management
- Add technical indicators
- Enhance logging and monitoring
