"""Zerodha Kite Trading Bot"""
__version__ = "1.0.0"
